import mongoose from "mongoose";
import { ENV } from "../core/config/env";
import { FastLogger } from "../core/logger/logger";

export async function initDatabase(): Promise<void> {
  try {
    await mongoose.connect(ENV.MONGO_URI, {
      maxPoolSize: 20,
      minPoolSize: 5,
      serverSelectionTimeoutMS: 5000,
      autoIndex: false
    });
    FastLogger.success("Database pool initialized");
  } catch (err) {
    FastLogger.error("Database connection failed", err);
    process.exit(1);
  }
}
