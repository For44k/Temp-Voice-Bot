import { Schema, model } from "mongoose";

export interface IGuildGame {
  name: string;
  roleId: string;
  emoji?: string;
}

export interface IGuildConfig {
  guildId: string;
  generatorId: string;
  categoryId?: string;
  logsChannelId?: string;
  rejectChannelId?: string;
  defaultLimit: number;
  panelImageUrl?: string;
  nameTemplate?: string;
  defaultStatus?: string;
  games?: IGuildGame[];
}

const GuildConfigSchema = new Schema<IGuildConfig>({
  guildId: { type: String, required: true, unique: true, index: true },
  generatorId: { type: String, required: true },
  categoryId: { type: String },
  logsChannelId: { type: String },
  rejectChannelId: { type: String },
  defaultLimit: { type: Number, default: 0 },
  panelImageUrl: { type: String },
  nameTemplate: { type: String },
  defaultStatus: { type: String },
  games: [{
    name: { type: String, required: true },
    roleId: { type: String, required: true },
    emoji: { type: String }
  }]
});

export const GuildConfigModel = model<IGuildConfig>("GuildConfig", GuildConfigSchema);
