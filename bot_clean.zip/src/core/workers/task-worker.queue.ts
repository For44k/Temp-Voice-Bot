import { Client, VoiceChannel, GuildMember, PermissionFlagsBits, ActivityType, REST, Routes, GatewayIntentBits } from "discord.js";
import { ENV } from "../config/env";
import { FastLogger } from "../logger/logger";

export type WorkerOp =
  | { type: "PERMIT"; channelId: string; guildId: string; memberId: string }
  | { type: "REJECT"; channelId: string; guildId: string; memberId: string; disconnect: boolean }
  | { type: "MUTE_VC"; guildId: string; memberId: string; mute: boolean }
  | { type: "DEAFEN_VC"; guildId: string; memberId: string; deaf: boolean }
  | { type: "LOCK"; channelId: string; guildId: string; everyoneId: string; lock: boolean }
  | { type: "TEXT_LOCK"; channelId: string; guildId: string; everyoneId: string; lock: boolean }
  | { type: "HIDE"; channelId: string; guildId: string; everyoneId: string; hidden: boolean }
  | { type: "OVERWRITE_DELETE"; channelId: string; guildId: string; targetId: string }
  | { type: "OVERWRITE_EDIT"; channelId: string; guildId: string; targetId: string; allow: string; deny: string }
  | { type: "SEND_PANEL"; channelId: string; payload: any }
  | { type: "MOVE_MEMBER"; guildId: string; memberId: string; channelId: string }
  | { type: "APPLY_PERMISSIONS"; channelId: string; overwrites: Array<{ id: string; allow: string; deny: string; type: number }> }
  | { type: "SET_STATUS"; channelId: string; status: string }
  | { type: "SEND_LOG"; channelId: string; payload: any }
  | { type: "DELETE_CHANNEL"; channelId: string };

export class TaskWorkerQueue {
  private static workerClient: Client | null = null;
  private static workerRest: REST | null = null;
  private static queue: WorkerOp[] = [];
  private static isProcessing = false;
  private static readonly CONCURRENCY = 20;

  public static get hasWorker(): boolean {
    return this.workerClient !== null;
  }

  public static get client(): Client | null {
    return this.workerClient;
  }

  public static get rest(): REST | null {
    return this.workerRest;
  }

  public static async init(): Promise<void> {
    if (!ENV.WORKER_TOKEN) {
      FastLogger.info("No WORKER_TOKEN — running single-bot mode.");
      return;
    }

    try {
      this.workerClient = new Client({
        intents: [
          GatewayIntentBits.Guilds,
          GatewayIntentBits.GuildVoiceStates
        ]
      });
      await this.workerClient.login(ENV.WORKER_TOKEN);
      this.workerRest = new REST({ version: "10" }).setToken(ENV.WORKER_TOKEN);
      FastLogger.success(`Worker Bot online as ${this.workerClient.user?.tag}`);
      this.workerClient.user?.setPresence({
        status: "dnd",
        activities: [{ name: "helping", type: ActivityType.Custom }]
      });
    } catch {
      FastLogger.warn("Worker bot failed to login — falling back to main bot for all ops.");
      this.workerClient = null;
      this.workerRest = null;
    }
  }

  public static dispatch(op: WorkerOp): void {
    this.queue.push(op);
    void this.processQueue();
  }

  public static dispatchBatch(ops: WorkerOp[]): void {
    if (ops.length === 0) return;
    this.queue.push(...ops);
    void this.processQueue();
  }

  private static async processQueue(): Promise<void> {
    if (this.isProcessing || this.queue.length === 0) return;
    this.isProcessing = true;

    const rest = this.workerRest;

    try {
      while (this.queue.length > 0) {
        const batch = this.queue.splice(0, this.CONCURRENCY);
        await Promise.allSettled(
          batch.map((op) => this.executeOp(op, rest))
        );
      }
    } finally {
      this.isProcessing = false;
      if (this.queue.length > 0) void this.processQueue();
    }
  }

  private static async executeOp(op: WorkerOp, rest: REST | null): Promise<void> {
    try {
      if (!rest) {
        FastLogger.warn(`No worker REST — skipping op ${op.type}`);
        return;
      }

      if (op.type === "PERMIT") {
        await rest.put(Routes.channelPermission(op.channelId, op.memberId), {
          body: {
            allow: String(
              PermissionFlagsBits.Connect |
              PermissionFlagsBits.ViewChannel |
              PermissionFlagsBits.SendMessages |
              PermissionFlagsBits.Speak |
              PermissionFlagsBits.Stream
            ),
            deny: "0",
            type: 1
          }
        });
        return;
      }

      if (op.type === "REJECT") {
        await rest.put(Routes.channelPermission(op.channelId, op.memberId), {
          body: {
            allow: String(PermissionFlagsBits.ViewChannel),
            deny: String(PermissionFlagsBits.Connect | PermissionFlagsBits.SendMessages),
            type: 1
          }
        });
        if (op.disconnect) {
          await rest.patch(Routes.guildMember(op.guildId, op.memberId), {
            body: { channel_id: null }
          }).catch(() => {});
        }
        return;
      }

      if (op.type === "LOCK") {
        await rest.put(Routes.channelPermission(op.channelId, op.everyoneId), {
          body: {
            allow: "0",
            deny: op.lock
              ? String(PermissionFlagsBits.Connect | PermissionFlagsBits.SendMessages)
              : "0",
            type: 0
          }
        });
        return;
      }

      if (op.type === "TEXT_LOCK") {
        await rest.put(Routes.channelPermission(op.channelId, op.everyoneId), {
          body: {
            allow: "0",
            deny: op.lock ? String(PermissionFlagsBits.SendMessages) : "0",
            type: 0
          }
        });
        return;
      }

      if (op.type === "HIDE") {
        await rest.put(Routes.channelPermission(op.channelId, op.everyoneId), {
          body: {
            allow: "0",
            deny: op.hidden ? String(PermissionFlagsBits.ViewChannel) : "0",
            type: 0
          }
        });
        return;
      }

      if (op.type === "OVERWRITE_DELETE") {
        await rest.delete(Routes.channelPermission(op.channelId, op.targetId));
        return;
      }

      if (op.type === "OVERWRITE_EDIT") {
        await rest.put(Routes.channelPermission(op.channelId, op.targetId), {
          body: { allow: op.allow, deny: op.deny, type: 1 }
        });
        return;
      }

      if (op.type === "MUTE_VC") {
        await rest.patch(Routes.guildMember(op.guildId, op.memberId), {
          body: { mute: op.mute }
        });
        return;
      }

      if (op.type === "DEAFEN_VC") {
        await rest.patch(Routes.guildMember(op.guildId, op.memberId), {
          body: { deaf: op.deaf }
        });
        return;
      }

      if (op.type === "MOVE_MEMBER") {
        await rest.patch(Routes.guildMember(op.guildId, op.memberId), {
          body: { channel_id: op.channelId }
        });
        return;
      }

      if (op.type === "APPLY_PERMISSIONS") {
        await Promise.allSettled(
          op.overwrites.map((ow) =>
            rest.put(Routes.channelPermission(op.channelId, ow.id), {
              body: { allow: ow.allow, deny: ow.deny, type: ow.type }
            })
          )
        );
        return;
      }

      if (op.type === "SET_STATUS") {
        await rest.put(`/channels/${op.channelId}/voice-status`, {
          body: { status: op.status }
        }).catch(() => {});
        return;
      }

      if (op.type === "SEND_PANEL" || op.type === "SEND_LOG") {
        await rest.post(Routes.channelMessages(op.channelId), {
          body: op.payload
        });
        return;
      }

      if (op.type === "DELETE_CHANNEL") {
        await rest.delete(Routes.channel(op.channelId));
        return;
      }
    } catch (err) {
      FastLogger.error(`Worker op failed [${op.type}]`, err);
    }
  }
}
