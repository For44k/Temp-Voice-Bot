import { Message, PermissionFlagsBits } from "discord.js";
import { ICommand } from "../../../../shared/types/command.types";
import { GuildConfigModel } from "../../../../database/schemas/guild-config.schema";
import { GuildMemoryStore } from "../../cache/guild.store";
import { WebhookLogger } from "../../../../core/logger/webhook.logger";
import { Usages } from "../../../../shared/embeds/usages";

export const panelimageCommand: ICommand = {
  name: "panelimage",
  prefixAliases: ["panelimage", "pimage", "setimage"],
  async executePrefix(message: Message, args: string[]): Promise<void> {
    const guildId = message.guildId!;

    if (!message.member?.permissions.has(PermissionFlagsBits.Administrator)) {
      await message.reply({
        ...(await Usages.impossible(guildId, "**__You need Administrator permissions to use this :__**")),
        allowedMentions: { parse: [] }
      });
      return;
    }

    const sub = args[0]?.toLowerCase();

    if (sub === "reset" || sub === "remove" || sub === "clear") {
      await GuildConfigModel.updateOne({ guildId }, { $unset: { panelImageUrl: 1 } }).exec();
      const cfg = await GuildMemoryStore.resolve(guildId);
      if (cfg) {
        delete cfg.panelImageUrl;
      }
      GuildMemoryStore["store"].delete(guildId);

      const embed = await Usages.executedAction(
        guildId,
        "Panel Image",
        "**__Panel image has been removed :__** The voice panel will now show without a custom image."
      );
      await message.reply({
        ...embed,
        allowedMentions: { parse: [] }
      });
      return;
    }

    const attachment = message.attachments.first();
    const possibleUrl = args.find((a) => /^https?:\/\/.+/i.test(a));

    if (!attachment && !possibleUrl) {
      await message.reply({
        ...(await Usages.invalidCommand(guildId, "`.v panelimage`", "<attach media | url>")),
        allowedMentions: { parse: [] }
      });
      return;
    }

    const imageUrl = attachment ? attachment.url : possibleUrl!;
    const processingMsg = await message.reply({
      ...(await Usages.executedAction(
        guildId,
        "Panel Image",
        "**__Uploading your image to storage...__**"
      )),
      allowedMentions: { parse: [] }
    });

    try {
      const response = await fetch(imageUrl);
      if (!response.ok) throw new Error("Failed to fetch image");
      const contentType = response.headers.get("content-type") || "";
      if (attachment && attachment.contentType && !attachment.contentType.startsWith("image/")) {
        throw new Error("Only image files are accepted (PNG, JPG, GIF, WEBP)");
      }
      if (contentType && !contentType.startsWith("image/") && !contentType.includes("octet-stream")) {

      }

      const arrayBuffer = await response.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);

      let ext = "png";
      if (attachment?.name) {
        ext = attachment.name.split(".").pop() || "png";
      } else if (possibleUrl) {
        const urlPath = new URL(possibleUrl).pathname;
        const match = urlPath.match(/\.(png|jpg|jpeg|gif|webp)$/i);
        if (match) ext = match[1];
      }

      const filename = `panel_${guildId}.${ext}`;
      const permanentUrl = await WebhookLogger.uploadImage(buffer, filename);

      const finalUrl = permanentUrl || imageUrl;

      await GuildConfigModel.updateOne(
        { guildId },
        { $set: { panelImageUrl: finalUrl } },
        { upsert: false }
      ).exec();

      GuildMemoryStore["store"].delete(guildId);

      await processingMsg.edit(
        await Usages.executedAction(
          guildId,
          "Panel Image",
          "Panel image has been updated and is now active for voice panels in this server."
        )
      );
    } catch (err: any) {
      await processingMsg.edit({
        ...(await Usages.impossible(guildId, `**__Error uploading image :__** ${err.message}`)),
      });
    }
  }
};
