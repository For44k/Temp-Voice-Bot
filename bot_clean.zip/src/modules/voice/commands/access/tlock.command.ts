import { Message, GuildMember, VoiceChannel } from "discord.js";
import { ICommand } from "../../../../shared/types/command.types";
import { VoiceLifecycleService } from "../../services/voice-lifecycle.service";
import { VoicePermissionsManager } from "../../services/voice-permission.service";
import { VoiceMemoryStore } from "../../cache/voice.store";
import { Usages } from "../../../../shared/embeds/usages";
import { extractTargetMembers } from "../../../../shared/utils/member-parser";

export const tlockCommand: ICommand = {
  name: "tlock",
  prefixAliases: ["tlock", "tmute"],
  async executePrefix(message: Message, args: string[]): Promise<void> {
    const member = message.member as GuildMember;
    const channel = member.voice.channel as VoiceChannel | null;
    const guildId = message.guildId;

    if (!channel) {
      await message.reply({ ...(await Usages.notInVoice(guildId)), allowedMentions: { parse: [] } });
      return;
    }

    if (!VoiceLifecycleService.isManager(channel.id, member.id)) {
      await message.reply({ ...(await Usages.notManagerOrOwner(guildId)), allowedMentions: { parse: [] } });
      return;
    }

    const targets = await extractTargetMembers(message, args);
    if (targets.length > 0) {
      await Promise.all(targets.map((t) => VoicePermissionsManager.muteUserText(channel, t, true)));
      const embed = await Usages.executedAction(
        guildId,
        "Text Mute",
        Usages.formatUserTarget("muted in chat", targets.map((t) => t.id))
      );
      await message.reply({ ...embed, allowedMentions: { parse: [] } });
      return;
    }

    const session = VoiceMemoryStore.get(channel.id);
    if (session) {
      session.isTextLocked = true;
      VoiceMemoryStore.sync(channel.id);
    }

    await VoicePermissionsManager.setTextLock(channel, true);
    const embed = await Usages.executedAction(
      guildId,
      "Text Lock",
      "**__Text chat has been locked :__** Only Permitted users can send messages."
    );
    await message.reply({ ...embed, allowedMentions: { parse: [] } });
  }
};
