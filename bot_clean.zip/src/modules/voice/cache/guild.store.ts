import { GuildConfigModel, IGuildConfig } from "../../../database/schemas/guild-config.schema";

export class GuildMemoryStore {
  private static store: Map<string, IGuildConfig> = new Map();

  public static async preload(): Promise<void> {
    try {
      const records = await GuildConfigModel.find().lean();
      for (const item of records) {
        this.store.set(item.guildId, item);
      }
    } catch {}
  }

  public static resolve(guildId: string): IGuildConfig | null {
    const memory = this.store.get(guildId);
    if (memory) return memory;
    return null;
  }

  public static async resolveAsync(guildId: string): Promise<IGuildConfig | null> {
    const memory = this.store.get(guildId);
    if (memory) return memory;

    try {
      const data = await GuildConfigModel.findOne({ guildId }).maxTimeMS(500).lean();
      if (data) {
        this.store.set(guildId, data);
        return data;
      }
    } catch {}
    return null;
  }

  public static set(guildId: string, data: IGuildConfig): void {
    this.store.set(guildId, data);
  }

  public static purge(guildId: string): void {
    this.store.delete(guildId);
  }
}
