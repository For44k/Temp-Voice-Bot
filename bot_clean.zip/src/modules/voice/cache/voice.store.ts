import { ActiveVoiceModel, IActiveVoice } from "../../../database/schemas/active-voice.schema";

export interface FastVoiceSession {
  channelId: string;
  guildId: string;
  ownerId: string;
  originalOwnerId: string;
  coOwners: Set<string>;
  whitelist: Set<string>;
  isLocked: boolean;
  isTextLocked: boolean;
  isHidden: boolean;
  antiAbuseEnabled?: boolean;
  channelMutes?: Set<string>;
  channelDeafens?: Set<string>;
  claimPromptMessageId?: string;
  antiAbuseAttempts?: Map<string, { count: number; lastTime: number; notified: boolean }>;
}

export class VoiceMemoryStore {
  private static channels: Map<string, FastVoiceSession> = new Map();
  private static ownerLookup: Map<string, string> = new Map(); 

  public static get(channelId: string): FastVoiceSession | undefined {
    return this.channels.get(channelId);
  }

  public static getByOwner(guildId: string, userId: string): FastVoiceSession | undefined {
    const channelId = this.ownerLookup.get(`${guildId}:${userId}`);
    return channelId ? this.channels.get(channelId) : undefined;
  }

  public static set(session: FastVoiceSession): void {
    this.channels.set(session.channelId, session);
    this.ownerLookup.set(`${session.guildId}:${session.ownerId}`, session.channelId);
  }

  public static reassignOwner(channelId: string, newOwnerId: string): void {
    const session = this.channels.get(channelId);
    if (!session) return;
    this.ownerLookup.delete(`${session.guildId}:${session.ownerId}`);
    session.ownerId = newOwnerId;
    this.ownerLookup.set(`${session.guildId}:${newOwnerId}`, channelId);
    ActiveVoiceModel.updateOne({ channelId }, { ownerId: newOwnerId }).exec().catch(() => {});
  }

  public static remove(channelId: string): void {
    const session = this.channels.get(channelId);
    if (session) {
      this.ownerLookup.delete(`${session.guildId}:${session.ownerId}`);
      this.channels.delete(channelId);
    }
    ActiveVoiceModel.deleteOne({ channelId }).exec().catch(() => {});
  }

  public static async preload(): Promise<void> {
    const records = await ActiveVoiceModel.find().lean();
    for (const item of records) {
      const session: FastVoiceSession = {
        channelId: item.channelId,
        guildId: item.guildId,
        ownerId: item.ownerId,
        originalOwnerId: item.originalOwnerId,
        coOwners: new Set(item.coOwners),
        whitelist: new Set(item.whitelist),
        isLocked: item.isLocked,
        isTextLocked: item.isTextLocked,
        isHidden: item.isHidden
      };
      this.channels.set(item.channelId, session);
      this.ownerLookup.set(`${item.guildId}:${item.ownerId}`, item.channelId);
    }
  }

  public static sync(channelId: string): void {
    const session = this.channels.get(channelId);
    if (!session) return;
    ActiveVoiceModel.updateOne(
      { channelId },
      {
        ownerId: session.ownerId,
        coOwners: Array.from(session.coOwners),
        whitelist: Array.from(session.whitelist),
        isLocked: session.isLocked,
        isTextLocked: session.isTextLocked,
        isHidden: session.isHidden
      },
      { upsert: true }
    ).exec().catch(() => {});
  }
}
