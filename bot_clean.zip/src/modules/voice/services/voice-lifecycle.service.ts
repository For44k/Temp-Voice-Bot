import { VoiceChannel, GuildMember, ChannelType, PermissionFlagsBits, OverwriteResolvable, Routes, REST } from "discord.js";
import { VoiceMemoryStore, FastVoiceSession } from "../cache/voice.store";
import { GuildMemoryStore } from "../cache/guild.store";
import { PreferencesStore } from "../../user/cache/preferences.store";
import { ActiveVoiceModel } from "../../../database/schemas/active-voice.schema";
import { UserProfileModel } from "../../../database/schemas/user-profile.schema";
import { PanelBuilder } from "../../../core/interactions/panel.builder";
import { GlobalBlacklistStore } from "../../user/cache/global-blacklist.store";
import { TaskWorkerQueue } from "../../../core/workers/task-worker.queue";
import { ActionLogger } from "../../../core/logger/action.logger";
import { FastLogger } from "../../../core/logger/logger";
import { ENV } from "../../../core/config/env";
import { BotDeveloperStore } from "../../user/cache/bot-developer.store";

const OWNER_ALLOW_BITS = String(
  PermissionFlagsBits.Connect |
  PermissionFlagsBits.Speak |
  PermissionFlagsBits.Stream |
  PermissionFlagsBits.ViewChannel |
  PermissionFlagsBits.MoveMembers |
  PermissionFlagsBits.SendMessages
);

const TRUSTED_ALLOW_BITS = String(
  PermissionFlagsBits.Connect |
  PermissionFlagsBits.Speak |
  PermissionFlagsBits.Stream |
  PermissionFlagsBits.ViewChannel |
  PermissionFlagsBits.SendMessages
);

const BLOCKED_DENY_BITS = String(
  PermissionFlagsBits.Connect |
  PermissionFlagsBits.SendMessages
);

export class VoiceLifecycleService {
  private static creatingUsers: Set<string> = new Set();
  private static renameCooldowns: Map<string, { count: number; resetAt: number }> = new Map();
  private static joinTimestamps: Map<string, number[]> = new Map();
  private static activeCooldowns: Map<string, number> = new Map();

  public static isCreating(userId: string): boolean {
    return this.creatingUsers.has(userId);
  }

  public static checkJoinRateLimit(userId: string): { isRateLimited: boolean; remainingSeconds: number } {
    const now = Date.now();

    if (this.creatingUsers.has(userId)) {
      return { isRateLimited: true, remainingSeconds: 2 };
    }

    const cooldownUntil = this.activeCooldowns.get(userId);
    if (cooldownUntil) {
      if (now < cooldownUntil) {
        return { isRateLimited: true, remainingSeconds: Math.ceil((cooldownUntil - now) / 1000) };
      }
      this.activeCooldowns.delete(userId);
    }

    const timestamps = this.joinTimestamps.get(userId) || [];
    const validTimestamps = timestamps.filter((t) => now - t <= 3500);
    validTimestamps.push(now);
    this.joinTimestamps.set(userId, validTimestamps);

    if (validTimestamps.length >= 2) {
      const cooldownExpiry = now + 3500;
      this.activeCooldowns.set(userId, cooldownExpiry);
      this.joinTimestamps.delete(userId);
      return { isRateLimited: true, remainingSeconds: 3 };
    }

    return { isRateLimited: false, remainingSeconds: 0 };
  }

  public static async createRoom(member: GuildMember): Promise<VoiceChannel | null> {
    if (GlobalBlacklistStore.isUserBlacklisted(member.id)) {
      void member.voice.disconnect().catch(() => {});
      return null;
    }

    if (this.creatingUsers.has(member.id)) return null;
    this.creatingUsers.add(member.id);

    try {
      const guild = member.guild;
      const config = GuildMemoryStore.resolve(guild.id);
      if (!config) return null;

      const prefs = PreferencesStore.getSync(guild.id, member.id);

      let channelName = `${member.displayName}'s Room`;
      if (config.nameTemplate) {
        channelName = config.nameTemplate
          .replace(/{username}/gi, member.displayName)
          .replace(/{user}/gi, member.user.username)
          .replace(/{server}/gi, guild.name)
          .slice(0, 100);
      }

      const rawOverwrites: Array<{ id: string; allow: string; deny: string; type: number }> = [];

      let parentChannel: any = null;
      if (config.categoryId) {
        parentChannel = guild.channels.cache.get(config.categoryId);
      }
      if (!parentChannel && config.generatorId) {
        const triggerChannel = guild.channels.cache.get(config.generatorId);
        if (triggerChannel?.parent) {
          parentChannel = triggerChannel.parent;
        } else {
          parentChannel = triggerChannel;
        }
      }

      if (parentChannel?.permissionOverwrites?.cache) {
        for (const ov of parentChannel.permissionOverwrites.cache.values()) {
          rawOverwrites.push({
            id: ov.id,
            allow: ov.allow.bitfield.toString(),
            deny: ov.deny.bitfield.toString(),
            type: ov.type
          });
        }
      }

      const existingOwnerOvIndex = rawOverwrites.findIndex((o) => o.id === member.id);
      if (existingOwnerOvIndex !== -1) {
        rawOverwrites[existingOwnerOvIndex] = {
          id: member.id,
          allow: OWNER_ALLOW_BITS,
          deny: "0",
          type: 1
        };
      } else {
        rawOverwrites.push({
          id: member.id,
          allow: OWNER_ALLOW_BITS,
          deny: "0",
          type: 1
        });
      }

      const extraWorkerOverwrites: Array<{ id: string; allow: string; deny: string; type: number }> = [];

      for (const blockedId of prefs.blacklist) {
        const isRole = guild.roles.cache.has(blockedId);
        const ovType = isRole ? 0 : 1;
        if (!TaskWorkerQueue.hasWorker) {
          rawOverwrites.push({
            id: blockedId,
            allow: String(PermissionFlagsBits.ViewChannel),
            deny: BLOCKED_DENY_BITS,
            type: ovType
          });
        } else {
          extraWorkerOverwrites.push({
            id: blockedId,
            allow: String(PermissionFlagsBits.ViewChannel),
            deny: BLOCKED_DENY_BITS,
            type: ovType
          });
        }
      }

      for (const trustedId of prefs.trusted) {
        const isRole = guild.roles.cache.has(trustedId);
        const ovType = isRole ? 0 : 1;
        if (!TaskWorkerQueue.hasWorker) {
          rawOverwrites.push({
            id: trustedId,
            allow: TRUSTED_ALLOW_BITS,
            deny: "0",
            type: ovType
          });
        } else {
          extraWorkerOverwrites.push({
            id: trustedId,
            allow: TRUSTED_ALLOW_BITS,
            deny: "0",
            type: ovType
          });
        }
      }

      for (const wlId of prefs.whitelist) {
        if (!prefs.trusted.has(wlId)) {
          const isRole = guild.roles.cache.has(wlId);
          const ovType = isRole ? 0 : 1;
          if (!TaskWorkerQueue.hasWorker) {
            rawOverwrites.push({
              id: wlId,
              allow: TRUSTED_ALLOW_BITS,
              deny: "0",
              type: ovType
            });
          } else {
            extraWorkerOverwrites.push({
              id: wlId,
              allow: TRUSTED_ALLOW_BITS,
              deny: "0",
              type: ovType
            });
          }
        }
      }

      const rest = guild.client.rest;
      const rawChannel = (await rest.post(Routes.guildChannels(guild.id), {
        body: {
          name: channelName,
          type: ChannelType.GuildVoice,
          parent_id: config.categoryId || undefined,
          user_limit: config.defaultLimit,
          permission_overwrites: rawOverwrites
        }
      })) as { id: string; name: string };

      const newChannelId = rawChannel.id;

      const session: FastVoiceSession = {
        channelId: newChannelId,
        guildId: guild.id,
        ownerId: member.id,
        originalOwnerId: member.id,
        coOwners: new Set(prefs.trusted),
        whitelist: new Set(prefs.whitelist),
        isLocked: false,
        isTextLocked: false,
        isHidden: false
      };
      VoiceMemoryStore.set(session);

      try {
        await rest.patch(Routes.guildMember(guild.id, member.id), {
          body: { channel_id: newChannelId }
        });
      } catch {
        
        VoiceMemoryStore.remove(newChannelId);
        void rest.delete(Routes.channel(newChannelId)).catch(() => {});
        return null;
      }

      if (TaskWorkerQueue.hasWorker && extraWorkerOverwrites.length > 0) {
        TaskWorkerQueue.dispatch({
          type: "APPLY_PERMISSIONS",
          channelId: newChannelId,
          overwrites: extraWorkerOverwrites
        });
      }

      if (config.defaultStatus) {
        const formattedStatus = config.defaultStatus
          .replace(/{username}/gi, member.displayName)
          .replace(/{user}/gi, member.user.username)
          .replace(/{server}/gi, guild.name)
          .slice(0, 500);

        if (TaskWorkerQueue.hasWorker) {
          TaskWorkerQueue.dispatch({
            type: "SET_STATUS",
            channelId: newChannelId,
            status: formattedStatus
          });
        } else {
          void rest.put(`/channels/${newChannelId}/voice-status`, {
            body: { status: formattedStatus }
          }).catch(() => {});
        }
      }

      setTimeout(() => {
        const activeCh = guild.channels.cache.get(newChannelId) as VoiceChannel | undefined;
        if (activeCh && activeCh.members.size === 0) {
          VoiceMemoryStore.remove(newChannelId);
          void activeCh.delete().catch(() => {});
        }
      }, 5000);

      queueMicrotask(async () => {
        try {
          const channel = (guild.channels.cache.get(newChannelId) as VoiceChannel | undefined) ??
            await guild.channels.fetch(newChannelId).catch(() => null) as VoiceChannel | null;

          if (channel && channel.isSendable()) {
            const [panel, musicActivityPanel] = await Promise.all([
              PanelBuilder.createPanel(guild.id, member.id),
              PanelBuilder.createMusicActivityPanel(guild.id)
            ]);
            await Promise.all([
              channel.send(panel).catch(() => {}),
              channel.send(musicActivityPanel).catch(() => {})
            ]);
          }

          if (config.logsChannelId && channel) {
            ActionLogger.logAction({
              guildId: guild.id,
              executorId: member.id,
              action: "Voice Channel Created",
              channelName: channel.name
            }).catch(() => {});
          }
        } catch {}

        ActiveVoiceModel.create({
          channelId: newChannelId,
          guildId: guild.id,
          ownerId: member.id,
          originalOwnerId: member.id,
          coOwners: Array.from(prefs.trusted),
          whitelist: Array.from(prefs.whitelist),
          isLocked: false,
          isTextLocked: false,
          isHidden: false
        }).catch(() => {});

        UserProfileModel.updateOne(
          { userId: member.id, guildId: guild.id },
          { $inc: { channelsCreated: 1 } },
          { upsert: true }
        ).exec().catch(() => {});
      });

      return null;
    } finally {
      this.creatingUsers.delete(member.id);
    }
  }

  public static canRename(channelId: string): { allowed: boolean; waitSeconds?: number } {
    const now = Date.now();
    const entry = this.renameCooldowns.get(channelId);

    if (!entry || now > entry.resetAt) {
      this.renameCooldowns.set(channelId, { count: 1, resetAt: now + 600000 });
      return { allowed: true };
    }

    if (entry.count < 2) {
      entry.count++;
      return { allowed: true };
    }

    const waitSeconds = Math.ceil((entry.resetAt - now) / 1000);
    return { allowed: false, waitSeconds };
  }

  public static async checkEmpty(channel: VoiceChannel): Promise<void> {
    if (channel.members.size === 0) {
      VoiceMemoryStore.remove(channel.id);
      this.renameCooldowns.delete(channel.id);

      try {
        await channel.delete();
      } catch {
        if (TaskWorkerQueue.hasWorker) {
          TaskWorkerQueue.dispatch({
            type: "DELETE_CHANNEL",
            channelId: channel.id
          });
        }
      }

      queueMicrotask(async () => {
        const config = await GuildMemoryStore.resolve(channel.guildId);
        if (config?.logsChannelId) {
          ActionLogger.logAction({
            guildId: channel.guildId,
            executorId: channel.id,
            action: "Voice Channel Deleted",
            channelName: channel.name
          }).catch(() => {});
        }
      });
    }
  }

  public static isManager(channelId: string, userId: string): boolean {
    if (BotDeveloperStore.isDeveloper(userId)) return true;
    const session = VoiceMemoryStore.get(channelId);
    if (!session) return false;
    return session.ownerId === userId || session.coOwners.has(userId);
  }

  public static isOwner(channelId: string, userId: string): boolean {
    if (BotDeveloperStore.isDeveloper(userId)) return true;
    const session = VoiceMemoryStore.get(channelId);
    return session?.ownerId === userId;
  }

  public static canManageTarget(channelId: string, actorId: string, targetId: string): boolean {
    if (BotDeveloperStore.isDeveloper(actorId)) return true;
    const session = VoiceMemoryStore.get(channelId);
    if (!session) return false;
    if (targetId === session.ownerId) return false;
    if (actorId === session.ownerId) return true;
    if (session.coOwners.has(actorId)) {
      if (session.coOwners.has(targetId)) return false;
      return true;
    }
    return false;
  }
}
