import { VoiceChannel, GuildMember, PermissionFlagsBits } from "discord.js";
import { TaskWorkerQueue } from "../../../core/workers/task-worker.queue";

export class VoicePermissionsManager {

  private static useWorker(): boolean {
    return TaskWorkerQueue.hasWorker;
  }

  public static async setConnectionLock(channel: VoiceChannel, lock: boolean): Promise<void> {
    const everyoneId = channel.guild.roles.everyone.id;
    if (this.useWorker()) {
      TaskWorkerQueue.dispatch({ type: "LOCK", channelId: channel.id, guildId: channel.guildId, everyoneId, lock });
    } else {
      await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
        Connect: lock ? false : null,
        SendMessages: lock ? false : null
      });
    }
  }

  public static async setTextLock(channel: VoiceChannel, lock: boolean): Promise<void> {
    const everyoneId = channel.guild.roles.everyone.id;
    if (this.useWorker()) {
      TaskWorkerQueue.dispatch({ type: "TEXT_LOCK", channelId: channel.id, guildId: channel.guildId, everyoneId, lock });
    } else {
      await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
        SendMessages: lock ? false : null
      });
    }
  }

  public static async setVisibility(channel: VoiceChannel, hidden: boolean): Promise<void> {
    const everyoneId = channel.guild.roles.everyone.id;
    if (this.useWorker()) {
      TaskWorkerQueue.dispatch({ type: "HIDE", channelId: channel.id, guildId: channel.guildId, everyoneId, hidden });
    } else {
      await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
        ViewChannel: hidden ? false : null
      });
    }
  }

  public static permitMember(channel: VoiceChannel, member: GuildMember): Promise<void> {
    if (this.useWorker()) {
      TaskWorkerQueue.dispatch({ type: "PERMIT", channelId: channel.id, guildId: channel.guildId, memberId: member.id });
      return Promise.resolve();
    }
    return channel.permissionOverwrites.edit(member, {
      Connect: true,
      ViewChannel: true,
      SendMessages: true,
      Speak: true,
      Stream: true
    }).then(() => {});
  }

  public static permitMemberSync(channel: VoiceChannel, member: GuildMember): void {
    TaskWorkerQueue.dispatch({ type: "PERMIT", channelId: channel.id, guildId: channel.guildId, memberId: member.id });
  }

  public static rejectMember(channel: VoiceChannel, member: GuildMember): void | Promise<void> {
    const disconnect = member.voice.channelId === channel.id;
    if (this.useWorker()) {
      TaskWorkerQueue.dispatch({ type: "REJECT", channelId: channel.id, guildId: channel.guildId, memberId: member.id, disconnect });
      return;
    }
    return (async () => {
      await channel.permissionOverwrites.edit(member, {
        Connect: false,
        ViewChannel: true,
        SendMessages: false
      });
      if (disconnect) await member.voice.disconnect().catch(() => {});
    })();
  }

  public static async kickMember(_channel: VoiceChannel, member: GuildMember): Promise<void> {
    if (member.voice.channelId) {
      await member.voice.disconnect().catch(() => {});
    }
  }

  public static resetMember(channel: VoiceChannel, member: GuildMember): Promise<void> {
    if (this.useWorker()) {
      TaskWorkerQueue.dispatch({ type: "OVERWRITE_DELETE", channelId: channel.id, guildId: channel.guildId, targetId: member.id });
      return Promise.resolve();
    }
    return channel.permissionOverwrites.delete(member).then(() => {});
  }

  public static muteUserText(channel: VoiceChannel, member: GuildMember, mute: boolean): Promise<void> {
    return channel.permissionOverwrites.edit(member, { SendMessages: mute ? false : null }).then(() => {});
  }

  public static muteVcMember(guildId: string, memberId: string, mute: boolean): void | Promise<void> {
    if (this.useWorker()) {
      TaskWorkerQueue.dispatch({ type: "MUTE_VC", guildId, memberId, mute });
      return;
    }
  }

  public static deafenVcMember(guildId: string, memberId: string, deaf: boolean): void | Promise<void> {
    if (this.useWorker()) {
      TaskWorkerQueue.dispatch({ type: "DEAFEN_VC", guildId, memberId, deaf });
      return;
    }
  }

  public static bulkPermit(channel: VoiceChannel, members: GuildMember[]): void {
    if (members.length === 0) return;
    if (this.useWorker()) {
      
      const mid = Math.ceil(members.length / 2);
      const workerBatch = members.slice(0, mid);
      const mainBatch = members.slice(mid);

      TaskWorkerQueue.dispatchBatch(
        workerBatch.map((m) => ({ type: "PERMIT" as const, channelId: channel.id, guildId: channel.guildId, memberId: m.id }))
      );

      for (const m of mainBatch) {
        void channel.permissionOverwrites.edit(m, { Connect: true, ViewChannel: true, SendMessages: true, Speak: true, Stream: true });
      }
    } else {
      for (const m of members) {
        void channel.permissionOverwrites.edit(m, { Connect: true, ViewChannel: true, SendMessages: true, Speak: true, Stream: true });
      }
    }
  }

  public static bulkReject(channel: VoiceChannel, members: GuildMember[]): void {
    if (members.length === 0) return;
    if (this.useWorker()) {
      
      const mid = Math.ceil(members.length / 2);
      const workerBatch = members.slice(0, mid);
      const mainBatch = members.slice(mid);

      TaskWorkerQueue.dispatchBatch(
        workerBatch.map((m) => ({
          type: "REJECT" as const,
          channelId: channel.id,
          guildId: channel.guildId,
          memberId: m.id,
          disconnect: m.voice.channelId === channel.id
        }))
      );

      for (const m of mainBatch) {
        void channel.permissionOverwrites.edit(m, { Connect: false, ViewChannel: true, SendMessages: false }).catch(() => {});
        if (m.voice.channelId === channel.id) void m.voice.disconnect().catch(() => {});
      }
    } else {
      for (const m of members) {
        void channel.permissionOverwrites.edit(m, { Connect: false, ViewChannel: true, SendMessages: false });
        if (m.voice.channelId === channel.id) void m.voice.disconnect().catch(() => {});
      }
    }
  }
}
