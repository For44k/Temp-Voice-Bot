import { initDatabase } from "./database/connection";
import { BotGateway } from "./core/gateway/bot.gateway";
import { FastLogger } from "./core/logger/logger";
import { TaskWorkerQueue } from "./core/workers/task-worker.queue";

async function main(): Promise<void> {
  await initDatabase();
  await TaskWorkerQueue.init();
  const bot = new BotGateway();
  await bot.start();
  FastLogger.info("One Tap Voice Manager is active");
}

process.on("unhandledRejection", (reason) => {
  FastLogger.error("Unhandled Promise Rejection", reason);
});

process.on("uncaughtException", (err) => {
  FastLogger.error("Uncaught Exception", err);
});

main().catch((err) => {
  FastLogger.error("Fatal error during bootstrap", err);
  process.exit(1);
});
